# Divra-Bloxd-Extention
13.04.2024
## Website Repository
https://github.com/BlxCode/Divra-Bloxd-Website
## Overview
Divra Bloxd Extention will be an upcoming extension for bloxd.io. It will replace Divra Bloxd Userscript and will have similar features too. 
What was Divra Bloxd Userscript
Divra Bloxd Userscript was one of the top 5 bloxd.io userscript made by Blxm. Divra Bloxd Userscipt’s official website is https://divra.vercel.app/. All installs for Divra Bloxd Userscript are deleted as of the user script null.
## Goals
⋅To increase player playtime
To help players play
## Specifications
Divra Userscipt will be the backbone for Divra Extention. All of Divra Userscript’s features will be in Divra Extention. Custom Crosshairs, Custom Hotbars, Live Sub Counts (no one has done that before), Home screen changes, etc.
## Milestones for Divra Extension
1. Update Version 1
Get everything that currently lives in Divra Userscript to Divra Extension. ✅
2. Update Version 2
Get all promised features in Divra Userscript to be in Divra Extensions.
3. Update Version 3
Could you get suggestions, and fix all bugs in Divra Extension?

