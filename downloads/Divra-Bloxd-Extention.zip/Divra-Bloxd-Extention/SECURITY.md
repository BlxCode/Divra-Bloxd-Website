# Security Policy

## Supported Versions

Supported versions for security updates are

| Version | Supported          |
| ------- | ------------------ |
| Latest Version   | :white_check_mark: |
| Divra Version b1.3p1 or lower   | :x:                |


## Reporting a Vulnerability
To report a security vulnerability, go to our discord and report it.
